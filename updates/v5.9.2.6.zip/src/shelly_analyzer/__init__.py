"""Shelly Energy Analyzer."""

__all__ = ["__version__"]

__version__ = "5.9.2.6"
